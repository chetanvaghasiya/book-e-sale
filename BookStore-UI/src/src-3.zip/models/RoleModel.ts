import { number } from "yup/lib/locale"

export default class RoleModel {
  id!: number;
  name!: string;
}