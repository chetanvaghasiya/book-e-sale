import { OrderAddModel } from "../models/OrderModel";
import request from "./request";

class OrderService {
	ENDPOINT = "api/Order";

	public async placeOrder(order: OrderAddModel): Promise<OrderAddModel> {
		const url = `${this.ENDPOINT}/add`;
        // console.log(order)
		return request
			.post<OrderAddModel>(url, order)
			.then((res) => {
				return res.data;
			})
			.catch((e) => {
				console.log(e);
				return Promise.resolve(e);
			});
	}
}

export default new OrderService();
